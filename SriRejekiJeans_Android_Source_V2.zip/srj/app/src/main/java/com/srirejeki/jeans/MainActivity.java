package com.srirejeki.jeans;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final String PREF = "srj_data";
    private static final int PICK_IMAGE = 1001;
    private static final String WA_DEFAULT = "6285642395381";

    private SharedPreferences prefs;
    private LinearLayout content;
    private EditText search;
    private TextView cartSummary;
    private ArrayList<Product> products = new ArrayList<>();
    private HashMap<Integer, Integer> cart = new HashMap<>();
    private int nextId = 1;
    private int editingProductId = -1;
    private Uri selectedImageUri;
    private ImageView pendingImagePreview;
    private AlertDialog pendingProductDialog;

    private String storeName = "SRI REJEKI JEANS";
    private String headline = "Jeans Wanita Pilihan";
    private String tagline = "Produksi sendiri • Jahitan rapi • Grosir • Reseller • Ecer";
    private String whatsapp = WA_DEFAULT;
    private String adminPin = "1234";

    static class Product {
        int id, price, grosir, stock;
        String name, category, imageUri;
        Product(int id, String name, String category, int price, int grosir, int stock, String imageUri) {
            this.id=id; this.name=name; this.category=category; this.price=price; this.grosir=grosir; this.stock=stock; this.imageUri=imageUri;
        }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREF, MODE_PRIVATE);
        loadData();
        buildShell();
        renderHome(products);
    }

    private void buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(247,244,239));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(8,6,8,6);
        nav.setBackgroundColor(Color.WHITE);
        Button home = navButton("Beranda");
        Button cartBtn = navButton("Keranjang");
        Button account = navButton("Akun");
        nav.addView(home, new LinearLayout.LayoutParams(0,60,1));
        nav.addView(cartBtn, new LinearLayout.LayoutParams(0,60,1));
        nav.addView(account, new LinearLayout.LayoutParams(0,60,1));
        root.addView(nav);

        home.setOnClickListener(v -> renderHome(products));
        cartBtn.setOnClickListener(v -> showCart());
        account.setOnClickListener(v -> showAccount());
        setContentView(root);
    }

    private Button navButton(String text) {
        Button b = new Button(this); b.setText(text); b.setTextSize(13); return b;
    }

    private void loadData() {
        storeName = prefs.getString("storeName", storeName);
        headline = prefs.getString("headline", headline);
        tagline = prefs.getString("tagline", tagline);
        whatsapp = prefs.getString("whatsapp", WA_DEFAULT);
        adminPin = prefs.getString("pin", "1234");
        String raw = prefs.getString("products", "");
        if (raw.isEmpty()) seed(); else {
            try {
                JSONArray a = new JSONArray(raw);
                for (int i=0;i<a.length();i++) {
                    JSONObject o=a.getJSONObject(i);
                    int id=o.getInt("id");
                    products.add(new Product(id,o.optString("name"),o.optString("category"),o.optInt("price"),o.optInt("grosir"),o.optInt("stock"),o.optString("imageUri","")));
                    nextId=Math.max(nextId,id+1);
                }
            } catch(Exception e){ seed(); }
        }
    }

    private void seed() {
        products.clear();
        products.add(new Product(nextId++,"Cutbray 7/9 Jeans Stretch","Cutbray",95000,85000,100,""));
        products.add(new Product(nextId++,"Legging Pencil Whisker","Legging",90000,80000,100,""));
        products.add(new Product(nextId++,"Cutbray Aurora","Cutbray",100000,90000,80,""));
        products.add(new Product(nextId++,"Celana Baggy Jeans","Baggy",105000,95000,70,""));
        products.add(new Product(nextId++,"Legging Jeans Jumbo","Legging",95000,85000,90,""));
        products.add(new Product(nextId++,"Boyfriend 7/9 Jeans","Boyfriend",100000,90000,60,""));
        saveData();
    }

    private void saveData() {
        try {
            JSONArray a=new JSONArray();
            for(Product p:products){
                JSONObject o=new JSONObject();
                o.put("id",p.id); o.put("name",p.name); o.put("category",p.category); o.put("price",p.price); o.put("grosir",p.grosir); o.put("stock",p.stock); o.put("imageUri",p.imageUri==null?"":p.imageUri);
                a.put(o);
            }
            prefs.edit().putString("products",a.toString()).putString("storeName",storeName).putString("headline",headline).putString("tagline",tagline).putString("whatsapp",whatsapp).putString("pin",adminPin).apply();
        } catch(Exception ignored) {}
    }

    private TextView text(String s,float size,int color) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }

    private void renderHome(ArrayList<Product> list) {
        content.removeAllViews();
        TextView logo=text(storeName,26,Color.rgb(20,40,74)); logo.setGravity(Gravity.CENTER); logo.setTypeface(null,1); logo.setPadding(0,14,0,4); content.addView(logo);
        search=new EditText(this); search.setSingleLine(true); search.setHint("Cari produk jeans wanita..."); content.addView(search,new LinearLayout.LayoutParams(-1,55));
        TextView banner=text(headline,25,Color.rgb(20,40,74)); banner.setTypeface(null,1); banner.setPadding(20,22,20,22); banner.setBackgroundColor(Color.rgb(233,223,208)); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.setMargins(0,14,0,0); content.addView(banner,bp);
        TextView tag=text(tagline,15,Color.DKGRAY); tag.setPadding(12,14,12,14); content.addView(tag);
        TextView prodTitle=text("PRODUK",21,Color.rgb(20,40,74)); prodTitle.setTypeface(null,1); prodTitle.setPadding(0,10,0,8); content.addView(prodTitle);
        LinearLayout listBox=new LinearLayout(this); listBox.setOrientation(LinearLayout.VERTICAL); content.addView(listBox);
        cartSummary=text("Keranjang: "+cartCount()+" item",16,Color.rgb(20,40,74)); cartSummary.setTypeface(null,1); cartSummary.setPadding(10,18,10,18); content.addView(cartSummary);
        for(Product p:list) addProductCard(listBox,p);
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){renderFiltered(s.toString());} public void afterTextChanged(Editable e){}});
    }

    private void renderFiltered(String q) {
        String x=q.toLowerCase(Locale.ROOT); ArrayList<Product> out=new ArrayList<>(); for(Product p:products) if(p.name.toLowerCase(Locale.ROOT).contains(x)||p.category.toLowerCase(Locale.ROOT).contains(x)) out.add(p);
        LinearLayout listBox=null;
        for(int i=0;i<content.getChildCount();i++){ View v=content.getChildAt(i); if(v instanceof LinearLayout && i>=4){ listBox=(LinearLayout)v; break; }}
        if(listBox==null) return; listBox.removeAllViews(); for(Product p:out) addProductCard(listBox,p);
    }

    private void addProductCard(LinearLayout parent, Product p) {
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(12,12,12,12); card.setBackgroundColor(Color.WHITE); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.setMargins(0,0,0,12); parent.addView(card,cp);
        if(p.imageUri!=null && !p.imageUri.isEmpty()) { ImageView im=new ImageView(this); im.setScaleType(ImageView.ScaleType.CENTER_CROP); try{im.setImageURI(Uri.parse(p.imageUri));}catch(Exception ignored){} card.addView(im,new LinearLayout.LayoutParams(-1,190)); }
        TextView t=text("👖  "+p.name+"\n"+money(p.price)+"   |   Grosir "+money(p.grosir)+"\nStok: "+p.stock,16,Color.rgb(20,40,74)); card.addView(t);
        Button add=new Button(this); add.setText(p.stock>0?"Tambah ke Keranjang":"Stok Habis"); add.setEnabled(p.stock>0); add.setOnClickListener(v->{int n=cart.containsKey(p.id)?cart.get(p.id):0; if(n<p.stock){cart.put(p.id,n+1);updateCart();Toast.makeText(this,"Ditambahkan ke keranjang",Toast.LENGTH_SHORT).show();}}); card.addView(add);
    }

    private void updateCart(){ if(cartSummary!=null) cartSummary.setText("Keranjang: "+cartCount()+" item"); }
    private int cartCount(){int n=0; for(int q:cart.values()) n+=q; return n;}
    private String money(int n){return "Rp "+String.format(Locale.US,"%,d",n).replace(',','.');}

    private void showCart(){
        content.removeAllViews(); TextView h=text("KERANJANG",24,Color.rgb(20,40,74)); h.setTypeface(null,1); content.addView(h);
        int total=0; StringBuilder msg=new StringBuilder("Halo "+storeName+", saya ingin order:\n");
        for(Map.Entry<Integer,Integer> e:cart.entrySet()){
            Product p=find(e.getKey()); if(p==null) continue; int qty=e.getValue(); total+=p.price*qty; msg.append("- ").append(p.name).append(" x").append(qty).append(" | ").append(money(p.price*qty)).append("\n");
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); TextView tx=text(p.name+"\n"+money(p.price)+" x "+qty,16,Color.DKGRAY); row.addView(tx,new LinearLayout.LayoutParams(0,-2,1)); Button minus=new Button(this); minus.setText("−"); Button plus=new Button(this); plus.setText("+"); row.addView(minus); row.addView(plus); content.addView(row); minus.setOnClickListener(v->{int z=cart.get(p.id)-1;if(z<=0)cart.remove(p.id);else cart.put(p.id,z);showCart();}); plus.setOnClickListener(v->{int z=cart.get(p.id);if(z<p.stock){cart.put(p.id,z+1);showCart();}else Toast.makeText(this,"Melebihi stok",Toast.LENGTH_SHORT).show();});
        }
        TextView tot=text("Total: "+money(total),20,Color.rgb(170,30,30)); tot.setTypeface(null,1); tot.setPadding(0,20,0,12); content.addView(tot);
        Button order=new Button(this); order.setText("Checkout via WhatsApp"); order.setOnClickListener(v->{try{String url="https://wa.me/"+whatsapp+"?text="+URLEncoder.encode(msg+"\nMohon info ukuran, warna, dan ongkir.","UTF-8");startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ignored){}}); content.addView(order);
        Button back=new Button(this); back.setText("Kembali ke Beranda"); back.setOnClickListener(v->renderHome(products)); content.addView(back);
    }

    private Product find(int id){for(Product p:products)if(p.id==id)return p;return null;}

    private void showAccount(){
        content.removeAllViews(); TextView h=text("AKUN & ADMIN",24,Color.rgb(20,40,74)); h.setTypeface(null,1); content.addView(h); TextView info=text(storeName+"\n\nWhatsApp: "+formatWa(whatsapp)+"\n\nSemua produk, harga, stok, foto, nama toko, banner, tagline dan nomor WhatsApp dapat diedit dari menu Admin.",17,Color.DKGRAY); info.setPadding(0,16,0,16); content.addView(info);
        Button admin=new Button(this); admin.setText("⚙️ EDIT TOKO / ADMIN"); admin.setOnClickListener(v->askPin()); content.addView(admin); Button home=new Button(this); home.setText("Kembali ke Beranda"); home.setOnClickListener(v->renderHome(products)); content.addView(home);
    }

    private String formatWa(String x){ if(x.startsWith("62")) return "0"+x.substring(2); return x; }

    private void askPin(){
        final EditText pin=new EditText(this); pin.setInputType(2); pin.setHint("PIN admin");
        new AlertDialog.Builder(this).setTitle("Login Admin").setMessage("PIN awal: 1234 (bisa diganti)").setView(pin).setNegativeButton("Batal",null).setPositiveButton("Masuk",(d,w)->{if(pin.getText().toString().equals(adminPin)) showAdmin(); else Toast.makeText(this,"PIN salah",Toast.LENGTH_SHORT).show();}).show();
    }

    private void showAdmin(){
        content.removeAllViews(); TextView h=text("PANEL ADMIN",25,Color.rgb(20,40,74)); h.setTypeface(null,1); content.addView(h);
        Button settingsBtn=new Button(this); settingsBtn.setText("✏️ Edit nama toko, banner & WhatsApp"); settingsBtn.setOnClickListener(v->editStore()); content.addView(settingsBtn);
        Button addBtn=new Button(this); addBtn.setText("➕ Tambah Produk"); addBtn.setOnClickListener(v->editProduct(null)); content.addView(addBtn);
        Button pinBtn=new Button(this); pinBtn.setText("🔐 Ganti PIN Admin"); pinBtn.setOnClickListener(v->changePin()); content.addView(pinBtn);
        TextView title=text("DAFTAR PRODUK",19,Color.rgb(20,40,74)); title.setTypeface(null,1); title.setPadding(0,20,0,10); content.addView(title);
        for(Product p:products) addAdminRow(p);
        Button back=new Button(this); back.setText("Kembali"); back.setOnClickListener(v->renderHome(products)); content.addView(back);
    }

    private void addAdminRow(Product p){
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(10,10,10,10); row.setBackgroundColor(Color.WHITE); TextView t=text(p.name+"\nEcer "+money(p.price)+" • Grosir "+money(p.grosir)+" • Stok "+p.stock,16,Color.DKGRAY); row.addView(t); LinearLayout buttons=new LinearLayout(this); Button edit=new Button(this); edit.setText("Edit"); Button del=new Button(this); del.setText("Hapus"); buttons.addView(edit,new LinearLayout.LayoutParams(0,55,1)); buttons.addView(del,new LinearLayout.LayoutParams(0,55,1)); row.addView(buttons); content.addView(row,new LinearLayout.LayoutParams(-1,-2)); edit.setOnClickListener(v->editProduct(p)); del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Hapus produk?").setMessage(p.name).setNegativeButton("Batal",null).setPositiveButton("Hapus",(d,w)->{products.remove(p);cart.remove(p.id);saveData();showAdmin();}).show());
    }

    private EditText field(String hint,String value){ EditText e=new EditText(this); e.setHint(hint); e.setText(value); e.setSingleLine(true); return e; }

    private void editStore(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(20,0,20,0);
        EditText n=field("Nama toko",storeName), h=field("Judul banner",headline), t=field("Tagline",tagline), w=field("WhatsApp (contoh 6285642395381)",whatsapp); box.addView(n);box.addView(h);box.addView(t);box.addView(w);
        new AlertDialog.Builder(this).setTitle("Edit Tampilan Toko").setView(box).setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,x)->{storeName=n.getText().toString().trim();headline=h.getText().toString().trim();tagline=t.getText().toString().trim();whatsapp=w.getText().toString().replaceAll("[^0-9]","");if(whatsapp.startsWith("0"))whatsapp="62"+whatsapp.substring(1);saveData();showAdmin();}).show();
    }

    private void editProduct(Product p){
        editingProductId=p==null?-1:p.id; selectedImageUri=(p!=null&&!p.imageUri.isEmpty())?Uri.parse(p.imageUri):null;
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(20,0,20,0);
        EditText name=field("Nama produk",p==null?"":p.name), cat=field("Kategori",p==null?"Jeans":p.category), price=field("Harga ecer",p==null?"":String.valueOf(p.price)), grosir=field("Harga grosir",p==null?"":String.valueOf(p.grosir)), stock=field("Stok",p==null?"":String.valueOf(p.stock));
        price.setInputType(2);grosir.setInputType(2);stock.setInputType(2); box.addView(name);box.addView(cat);box.addView(price);box.addView(grosir);box.addView(stock);
        Button photo=new Button(this); photo.setText("📷 Pilih / Ganti Foto Produk"); box.addView(photo);
        pendingImagePreview=new ImageView(this); pendingImagePreview.setAdjustViewBounds(true); if(selectedImageUri!=null)pendingImagePreview.setImageURI(selectedImageUri); box.addView(pendingImagePreview,new LinearLayout.LayoutParams(-1,180));
        photo.setOnClickListener(v->{pendingProductDialog=null;startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE),PICK_IMAGE);});
        pendingProductDialog=new AlertDialog.Builder(this).setTitle(p==null?"Tambah Produk":"Edit Produk").setView(box).setNegativeButton("Batal",null).setPositiveButton("Simpan",null).create();
        pendingProductDialog.setOnShowListener(x->pendingProductDialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{String nm=name.getText().toString().trim(); if(nm.isEmpty()){name.setError("Wajib diisi");return;} int pr=Integer.parseInt(price.getText().toString().trim());int gr=Integer.parseInt(grosir.getText().toString().trim());int st=Integer.parseInt(stock.getText().toString().trim()); if(p==null){products.add(new Product(nextId++,nm,cat.getText().toString().trim(),pr,gr,st,selectedImageUri==null?"":selectedImageUri.toString()));}else{p.name=nm;p.category=cat.getText().toString().trim();p.price=pr;p.grosir=gr;p.stock=st;p.imageUri=selectedImageUri==null?"":selectedImageUri.toString();}saveData();pendingProductDialog.dismiss();showAdmin();}catch(Exception e){Toast.makeText(this,"Periksa harga dan stok",Toast.LENGTH_SHORT).show();}}));
        pendingProductDialog.show();
    }

    private void changePin(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(20,0,20,0);EditText old=field("PIN lama","");EditText neu=field("PIN baru","");old.setInputType(2);neu.setInputType(2);box.addView(old);box.addView(neu);
        new AlertDialog.Builder(this).setTitle("Ganti PIN").setView(box).setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->{if(old.getText().toString().equals(adminPin)&&neu.getText().toString().length()>=4){adminPin=neu.getText().toString();saveData();Toast.makeText(this,"PIN berhasil diganti",Toast.LENGTH_SHORT).show();}else Toast.makeText(this,"PIN lama salah atau PIN baru kurang dari 4 angka",Toast.LENGTH_LONG).show();}).show();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==PICK_IMAGE&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){selectedImageUri=data.getData();try{getContentResolver().takePersistableUriPermission(selectedImageUri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}if(pendingImagePreview!=null)pendingImagePreview.setImageURI(selectedImageUri);}}
}
