# Sri Rejeki Jeans — Android Source

Source project Android Studio untuk aplikasi Sri Rejeki Jeans.

Fitur demo:
- Katalog produk
- Pencarian
- Harga ecer & grosir
- Stok
- Keranjang
- Checkout WhatsApp 085642395381
- Halaman akun dasar

Penting:
Project ini adalah source Android siap dibuka di Android Studio. Database online, login aman, upload foto, pembayaran, ongkir, dan panel admin server masih perlu diintegrasikan sebelum produksi.

Build:
1. Buka folder ini di Android Studio.
2. Tunggu Gradle sync.
3. Run pada emulator/perangkat Android.
4. Build > Build APK(s) untuk menghasilkan APK debug.

Untuk produksi, backend seperti Firebase/Supabase dapat ditambahkan.
