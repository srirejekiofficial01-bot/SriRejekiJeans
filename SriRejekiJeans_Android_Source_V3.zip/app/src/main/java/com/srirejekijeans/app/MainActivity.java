package com.srirejekijeans.app;
import android.app.*;import android.os.*;import android.content.*;import android.net.*;import android.webkit.*;
public class MainActivity extends Activity{
 WebView w; ValueCallback<Uri[]> cb;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);w=findViewById(R.id.webView);
  WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);
  w.setWebViewClient(new WebViewClient());w.setWebChromeClient(new WebChromeClient(){
   public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> c,FileChooserParams p){
    cb=c;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");startActivityForResult(i,1001);return true;}});
  w.loadUrl("file:///android_asset/index.html");
 }
 protected void onActivityResult(int r,int c,Intent d){if(r==1001&&cb!=null){cb.onReceiveValue(c==RESULT_OK&&d!=null&&d.getData()!=null?new Uri[]{d.getData()}:null);cb=null;}super.onActivityResult(r,c,d);}
 @Override public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed();}
}
