package com.srirejeki.jeans;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout productList; TextView cartSummary; EditText search; ArrayList<Product> products=new ArrayList<>(); ArrayList<Product> cart=new ArrayList<>();
    final String WA="6285642395381";
    static class Product { String name,cat; int price,grosir,stock; Product(String n,String c,int p,int g,int s){name=n;cat=c;price=p;grosir=g;stock=s;} }
    public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main); bind(); seed(); render(products);
        findViewById(R.id.cartBtn).setOnClickListener(v->showCart());
        findViewById(R.id.accountBtn).setOnClickListener(v->showAccount());
        findViewById(R.id.homeBtn).setOnClickListener(v->render(products));
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){} public void onTextChanged(CharSequence s,int a,int b,int c){filter(s.toString());} public void afterTextChanged(android.text.Editable e){}});
    }
    void bind(){productList=findViewById(R.id.productList);cartSummary=findViewById(R.id.cartSummary);search=findViewById(R.id.search);}
    void seed(){products.add(new Product("Cutbray 7/9 Jeans Stretch","Cutbray",95000,85000,100));products.add(new Product("Legging Pencil Whisker","Legging",90000,80000,100));products.add(new Product("Cutbray Aurora","Cutbray",100000,90000,80));products.add(new Product("Celana Baggy Jeans","Baggy",105000,95000,70));products.add(new Product("Legging Jeans Jumbo","Legging",95000,85000,90));products.add(new Product("Boyfriend 7/9 Jeans","Boyfriend",100000,90000,60));}
    String money(int n){return "Rp "+String.format(java.util.Locale.US,"%,d",n).replace(',','.');}
    void render(List<Product> list){productList.removeAllViews(); for(Product p:list){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(14,14,14,14); TextView t=new TextView(this);t.setText("👖  "+p.name+"\n"+money(p.price)+"   |   Grosir "+money(p.grosir)+"\nStok: "+p.stock);t.setTextSize(16);t.setTextColor(Color.rgb(20,40,74));box.addView(t);Button add=new Button(this);add.setText("Tambah ke Keranjang");add.setOnClickListener(v->{cart.add(p);updateCart();Toast.makeText(this,"Ditambahkan",Toast.LENGTH_SHORT).show();});box.addView(add);productList.addView(box);}}
    void filter(String q){ArrayList<Product> x=new ArrayList<>();for(Product p:products)if(p.name.toLowerCase().contains(q.toLowerCase()))x.add(p);render(x);}
    void updateCart(){cartSummary.setText("Keranjang: "+cart.size()+" item");}
    void showCart(){productList.removeAllViews();TextView h=new TextView(this);h.setText("KERANJANG\n");h.setTextSize(24);h.setTextColor(Color.rgb(20,40,74));productList.addView(h);int total=0;StringBuilder msg=new StringBuilder("Halo Sri Rejeki Jeans, saya ingin order:%0A");for(Product p:cart){total+=p.price;TextView x=new TextView(this);x.setText("• "+p.name+" — "+money(p.price));x.setTextSize(16);x.setPadding(0,10,0,10);productList.addView(x);msg.append("- ").append(p.name).append(" | ").append(money(p.price)).append("%0A");}TextView tot=new TextView(this);tot.setText("Total: "+money(total));tot.setTextSize(20);tot.setTextColor(Color.RED);productList.addView(tot);Button order=new Button(this);order.setText("Checkout via WhatsApp");order.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"+WA+"?text="+msg.toString()+"%0AMohon info stok, ukuran, warna, dan ongkir."));startActivity(i);});productList.addView(order);}
    void showAccount(){productList.removeAllViews();TextView t=new TextView(this);t.setText("AKUN & RESELLER\n\nLogin reseller dan pelanggan dapat dikembangkan pada tahap database online.\n\nWhatsApp: 085642395381\n\nUntuk menjadi reseller, hubungi admin.");t.setTextSize(17);t.setPadding(8,20,8,20);productList.addView(t);}
}